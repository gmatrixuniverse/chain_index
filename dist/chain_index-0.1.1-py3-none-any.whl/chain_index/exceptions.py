class ChainNotFoundError(Exception):
    """Raised when a requested chain is not found in the index."""
    pass
